1. npm install
2. npx hardhat compile
3. enter your private key of ethereum wallet account in .secret file
4. npx hardhat run --network kovan scipts/deploy.js
5. npm run build
6. npm run start
