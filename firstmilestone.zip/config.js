export const nftmarketaddress = "0x8437FdEbE92a80BD225B106DC60164277169F971"
export const nftaddress = "0x802369FA913a1C68a112984249ABa2ea617e4d26"
  